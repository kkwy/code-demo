<template>
  <div class="about">
    <h1>This is an about page</h1>
    <cube-button>cube-button</cube-button>
  </div>
</template>
