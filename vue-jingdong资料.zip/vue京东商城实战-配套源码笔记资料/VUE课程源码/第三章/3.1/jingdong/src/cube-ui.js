import Vue from 'vue'
import Cube from 'cube-ui'

Vue.use(Cube)
