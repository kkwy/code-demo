package com.example.mybtiesplusdemo;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan("com.example.mybtiesplusdemo.mapper")
public class MybtiesplusdemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(MybtiesplusdemoApplication.class, args);
    }

}
