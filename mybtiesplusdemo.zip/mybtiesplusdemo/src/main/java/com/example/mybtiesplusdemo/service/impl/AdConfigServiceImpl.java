package com.example.mybtiesplusdemo.service.impl;

import com.example.mybtiesplusdemo.entity.AdConfig;
import com.example.mybtiesplusdemo.mapper.AdConfigMapper;
import com.example.mybtiesplusdemo.service.IAdConfigService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author shulicai
 * @since 2022-10-25
 */
@Service
public class AdConfigServiceImpl extends ServiceImpl<AdConfigMapper, AdConfig> implements IAdConfigService {

}
