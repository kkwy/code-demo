package com.example.mybtiesplusdemo.mapper;

import com.example.mybtiesplusdemo.entity.AdConfig;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author shulicai
 * @since 2022-10-25
 */
public interface AdConfigMapper extends BaseMapper<AdConfig> {

}
