package com.example.mybtiesplusdemo.controller;

import com.example.mybtiesplusdemo.entity.AdConfig;
import com.example.mybtiesplusdemo.service.IAdConfigService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author shulicai
 * @since 2022-10-25
 */
@RestController
@RequestMapping("/adConfig")
public class AdConfigController {
    @Autowired
    private IAdConfigService iAdConfigService;
    @GetMapping("test")
    public Object test(){
        ArrayList<AdConfig> adConfigs = new ArrayList<>();
        AdConfig adConfig = new AdConfig();
        adConfig.setId(123l);
        AdConfig adConfig1 = new AdConfig();
        adConfig1.setId(1232l);
        adConfigs.add(adConfig);
        adConfigs.add(adConfig1);
        iAdConfigService.saveBatch(adConfigs);
        return iAdConfigService.list();
    }


}
