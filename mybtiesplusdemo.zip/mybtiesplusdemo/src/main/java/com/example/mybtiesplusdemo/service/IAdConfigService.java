package com.example.mybtiesplusdemo.service;

import com.example.mybtiesplusdemo.entity.AdConfig;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author shulicai
 * @since 2022-10-25
 */
public interface IAdConfigService extends IService<AdConfig> {

}
