package com.example.mybtiesplusdemo;

import com.baomidou.mybatisplus.generator.FastAutoGenerator;
import com.baomidou.mybatisplus.generator.config.OutputFile;

import java.util.Collections;

/**
 * @author shulicai
 * @date 2022/10/25
 */
public class Test {
    public static void main(String[] args) {
        FastAutoGenerator.create("jdbc:mysql://1.14.98.107:3306/shop_order_0", "root", "KuLdw=aZy6c36")
                .globalConfig(builder -> {
                    builder.author("shulicai") // 设置作者f
//                            .enableSwagger() // 开启 swagger 模式
                            .outputDir("E:\\codedemo"); // 指定输出目录
                })
                .packageConfig(builder -> {
                    builder.parent("com.example.mybtiesplusdemo") // 设置父包名
                            .pathInfo(Collections.singletonMap(OutputFile.xml, "E:\\codedemo\\mapper")); // 设置mapperXml生成路径
                })
                .strategyConfig(builder -> {
                    builder.addInclude("ad_config"); // 设置需要生成的表名
                })
                .execute();


    }
}
