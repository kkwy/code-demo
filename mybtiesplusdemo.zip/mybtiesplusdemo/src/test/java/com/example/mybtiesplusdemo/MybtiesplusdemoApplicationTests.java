package com.example.mybtiesplusdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MybtiesplusdemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
