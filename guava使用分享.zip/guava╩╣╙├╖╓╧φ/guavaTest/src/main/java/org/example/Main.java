package org.example;

import com.google.common.base.Optional;


public class Main {
    public static void main(String[] args) {
//        optional();
        test();
    }

    public static void test(){
        Optional<Integer> possible = Optional.absent();
        System.out.println(possible.isPresent());
        System.out.println(possible.get());
    }
    public static void optional(){
        Optional<Integer> possible = Optional.of(5);
        possible.isPresent(); // returns true
        possible.get(); // returns 5
    }
}