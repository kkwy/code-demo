package org.example;

import com.google.common.base.CharMatcher;
import com.google.common.base.Joiner;
import com.google.common.base.Splitter;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Lists;

import java.util.List;
import java.util.Map;

public class StringDemo {
    public static void main(String[] args) {
        test3();
//        test1();
    }

    /**
     * Joiner 拼接字符串
     */
    public static void test1(){
        List<String> words  = Lists.newArrayList("123","456","789",null);
        //使用guava
        System.out.println(Joiner.on(",").useForNull("default").join(words));
        System.out.println(Joiner.on(",").skipNulls().join(words));

        Map<String, String> data = ImmutableMap.of("a", "1", "b", "2");
        System.out.println(Joiner.on(",").withKeyValueSeparator("-").join(data));
    }
    /**
     * Splitter 分割字符串
     */
    public static void test2(){
        //omitEmptyStrings 用来省略空白
        Splitter.on(",").omitEmptyStrings().splitToList("123,456,789,,23").forEach(a->{
            System.out.println(a);
        });
        //limit 用来限制结果个数，也就是前几个分隔符会生效
        Splitter.on(",").limit(2).splitToList("123,456,789,,23").forEach(a->{
            System.out.println(a);
        });
        //trimResults 去除结果头尾空格
        Splitter.on(",").trimResults().splitToList("12 3, 456 ,789,,23").forEach(a->{
            System.out.println(a);
        });
        //withKeyValueSeparator 将String转换Map
        Map<String,String> map = Splitter.on(",").withKeyValueSeparator("-").split("1-2,3-5");
        System.out.println(map);
    }
    /**
     * CharMatcher 用来从字符串匹配出自己想要的那部分
     */
    public static void test3(){
        System.out.println(CharMatcher.digit().retainFrom("asfds12312fds444"));
        //12312444
        System.out.println(CharMatcher.digit().removeFrom("asfds12312fds444"));
        //asfdsfds
        System.out.println(CharMatcher.digit().or(CharMatcher.whitespace()).retainFrom("as fds123 12 fds444"));
        // 123 12 444
        System.out.println(CharMatcher.javaDigit().replaceFrom("sdfsd2343454", "*"));
        //sdfsd*******
        System.out.println(CharMatcher.javaDigit().or(CharMatcher.javaLowerCase()).retainFrom("UUUsl3434lAAsl"));
        //sl3434lsl

    }
}
