package org.example;

import com.google.common.base.Function;
import com.google.common.collect.*;
import com.google.common.primitives.Ints;

import java.util.*;

public class CollectionDemo {
    public static void main(String[] args) {
        test8();
    }

    /**
     * MultiSet 可以用来统计集合内元素出现的次数
     */
    public static void test1(){
        List<String> words = Lists.newArrayList("a","b","c","b","b","c");

        Multiset<String> multiset1 = HashMultiset.create();
        for(String word : words){
            multiset1.add(word);
        }
        System.out.println(multiset1);
        System.out.println(multiset1.count("b"));
        Multiset<String> multiset2 = HashMultiset.create(words);
        multiset2.add("d",4);
        System.out.println(multiset2);
    }
    /**
     * SortedMultiset Multiset的变体，增加了针对元素次数的排序功能
     */
    public static void test2(){
        SortedMultiset<Integer> sortedMultiset = TreeMultiset.create();
        sortedMultiset.add(2,3);
        sortedMultiset.add(3,5);
        sortedMultiset.add(4,4);
        System.out.println(sortedMultiset);
        sortedMultiset = sortedMultiset.descendingMultiset();
        System.out.println(sortedMultiset);
        System.out.println(sortedMultiset.firstEntry().getElement());

        sortedMultiset = sortedMultiset.subMultiset(3,BoundType.OPEN,2,BoundType.CLOSED);
        System.out.println(sortedMultiset);

        //output
        //[2 x 3, 3 x 5, 4 x 4]
        //[4 x 4, 3 x 5, 2 x 3]
        //4
        //[2 x 3]
    }

    /**
     * MultiMap 可以理解为对Map<k, list>
     */
    public static void test3(){
        ListMultimap<String,Integer> listMultimap = MultimapBuilder
                .treeKeys()
                .arrayListValues()
                .build();
        listMultimap.put("1",1);
        listMultimap.put("1",2);
        listMultimap.put("2",1);
        System.out.println(listMultimap);

        List<Integer> value = listMultimap.get("1");
        value.add(3);
        System.out.println(listMultimap);

        listMultimap.removeAll("2");
        listMultimap.remove("1",1);
        System.out.println(listMultimap);

        Map<String, Collection<Integer>> mapView = listMultimap.asMap();
        System.out.println(mapView);

        SetMultimap<String,Integer> setMultimap = MultimapBuilder
                .treeKeys()
                .hashSetValues()
                .build();
        //output
        //{1=[1, 2], 2=[1]}
        //{1=[1, 2, 3], 2=[1]}
        //{1=[2, 3]}
        //{1=[2, 3]}
    }
    /**
     * BiMap 提供的功能是反转，就是说Map转换为Map。通过这个数据结构能够满足你需要通过value去查key的需求，而不是同时维护两个map
     * 需要注意的是 value不能重复，不然会报错
     */
    public static void test4(){
        BiMap<String,String> biMap = HashBiMap.create();
        biMap.put("scj","programmer");
        //biMap.put("scj2","programmer");

        System.out.println(biMap.get("scj"));
        System.out.println(biMap.inverse().get("programmer"));
        //output
        //programmer
        //scj
    }
    /**
     * Table 他提供了两个维度去找到我们的数据。 可以理解为Map<key,Map>
     * 三个泛型分别为Row,Column,Value get方法通过row和column定位value
     * row/column方法通过Row/Column的维度得到对应的Map
     */
    public static void test5(){
        Table<String,String,String> table = HashBasedTable.create();
        table.put("male","programmer","scj");
        table.put("female","beauty","ss");
        table.put("female","programmer","s2");

        System.out.println(table.get("male","programmer"));
        System.out.println(table.row("male").get("programmer"));
        System.out.println(table.column("programmer").get("female"));
        //output
        //scj
        //scj
        //s2

    }
    /**
     * 集合工具类 Lists
     */
    public static void test6(){
        //Lists
        List<String> test = new ArrayList<String>();
        List<String> test2 = Lists.newArrayList();
        List<String> test3 = Lists.newArrayList("1","2");
        List<String> test4 = Lists.newArrayList(test);

        List<Integer> countUp = Ints.asList(1, 2, 3, 4, 5);
        //翻转集合
        List<Integer> countDown = Lists.reverse(countUp); // {5, 4, 3, 2, 1}
        //返回基础集合的视图，该集合被划分为指定大小的块。
        List<List<Integer>> parts = Lists.partition(countUp, 2); // {{1, 2}, {3, 4}, {5}}
        //注意返回的试图 不能add remove 会报错 可以修改 但会影响原集合
//        parts.get(0).add(6);
//        parts.get(0).remove(0);
        parts.get(0).set(0,6);
        System.out.println(parts); //[[6, 2], [3, 4], [5]]
        System.out.println(countUp); //[6, 2, 3, 4, 5]

    }

    /**
     *
     * Sets
     */
    public static void test7(){
        //Sets
        Set<String> wordsWithPrimeLength = ImmutableSet.of("one", "two", "three", "six", "seven", "eight");
        Set<String> primes = ImmutableSet.of("two", "three", "five", "seven");
        //交集
        Sets.SetView<String> intersection = Sets.intersection(primes, wordsWithPrimeLength);
        System.out.println(intersection); //[two, three, seven]
        //并集
        Sets.SetView<String> union = Sets.union(primes, wordsWithPrimeLength);
        System.out.println(union);// [two, three, five, seven, one, six, eight]
        //差集
        Sets.SetView<String> difference = Sets.difference(primes, wordsWithPrimeLength);
        System.out.println(difference); //[five]

        //复制到另一个不可变集合
        ImmutableSet<String> strings = difference.immutableCopy();
        //复制到另一个可变集合
        difference.copyInto(Sets.newHashSet());

        Set<String> animals = ImmutableSet.of("gerbil", "hamster");
        Set<String> fruits = ImmutableSet.of("apple", "orange", "banana");
        //获取笛卡尔积
        Set<List<String>> product = Sets.cartesianProduct(animals, fruits);
        // {{"gerbil", "apple"}, {"gerbil", "orange"}, {"gerbil", "banana"},
        //  {"hamster", "apple"}, {"hamster", "orange"}, {"hamster", "banana"}}
        //获取某个集合的所有子集
        Set<Set<String>> animalSets = Sets.powerSet(animals);
        // {{}, {"gerbil"}, {"hamster"}, {"gerbil", "hamster"}}
    }
    /**
     *
     * Maps
     */
    public static void test8(){
        //Maps.uniqueIndex
        List<String> strings = Lists.newArrayList("we", "werewr", "sersersere");
        // 即拥有一堆对象，每个对象都有一些唯一的属性，并且希望能够根据该属性查找这些对象。
        ImmutableMap<Integer, String> stringsByIndex = Maps.uniqueIndex(strings, new Function<String, Integer>() {
            public Integer apply(String string) {
                return string.length();
            }
        });
        System.out.println(stringsByIndex); //{2=we, 6=werewr, 10=sersersere}
        //Maps.difference
        Map<String, Integer> left = ImmutableMap.of("a", 1, "b", 2, "c", 3);
        Map<String, Integer> right = ImmutableMap.of("b", 2, "c", 4, "d", 5);
        MapDifference<String, Integer> diff = Maps.difference(left, right);

        //返回键和值都相同的值
        diff.entriesInCommon(); // {"b" => 2}
        //返回键相同的值
        diff.entriesDiffering(); // {"c" => (3, 4)}
        //返回左map特有的键
        diff.entriesOnlyOnLeft(); // {"a" => 1}
        //返回右map特有的键
        diff.entriesOnlyOnRight(); // {"d" => 5}
    }
}
