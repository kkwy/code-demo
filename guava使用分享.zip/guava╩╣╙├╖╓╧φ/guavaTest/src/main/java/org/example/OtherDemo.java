package org.example;

import com.google.common.base.Charsets;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.google.common.hash.BloomFilter;
import com.google.common.hash.Funnel;
import com.google.common.hash.PrimitiveSink;

import java.util.concurrent.TimeUnit;

public class OtherDemo {
    public static void main(String[] args) {
        try {
            test2();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * 本地缓存的工具类
     * @throws Exception
     */
    public static void test() throws Exception{
        LoadingCache<String,String> cache = CacheBuilder.newBuilder()
                .maximumSize(100)
//                .maximumWeight(1000)
//                .weigher(new Weigher<String, String>() {
//                    @Override
//                    public int weigh(String key, String value) {
//                        return key.length();
//                    }
//                })
// expireAfterAccess会在缓存read或write后指定时间后失效。
// expireAfterWrite会在缓存write后指定时间后失效。
                .expireAfterAccess(10, TimeUnit.MINUTES)
//                .expireAfterWrite(10, TimeUnit.MINUTES)

//缓存生成策略通过CacheLoader来封装我们缓存的生成逻辑。我们可以预先初始化缓存，当get的时候，如果key不在缓存中，就会通过CacheLoader来生成我们的缓存。
                .build(new CacheLoader<String, String>() {
                    @Override
                    public String load(String key) throws Exception {
                        return key+"cache";
                    }
                });
        cache.put("test","23333");
        System.out.println(cache.get("test"));
        System.out.println(cache.get("scj"));
        //output
        //2333
        //scjcache
    }

    /**
     * 布隆过滤器 它允许你检测某个对象是一定不在过滤器中，还是可能已经添加到过滤器了
     */
    public static void test2(){
        BloomFilter<String> friends = BloomFilter.create(new Funnel<String>() {
            @Override
            public void funnel(String s, PrimitiveSink primitiveSink) {
                primitiveSink.putString(s, Charsets.UTF_8);
            }
        }, 500, 0.01);
        friends.put("ssss");
        friends.put("dddd");
        friends.put("ffff");
        friends.put("eeee");
        friends.put("aa");
// much later
        if (friends.mightContain("aa")) {
            System.out.println("11111");
        }
    }
}
